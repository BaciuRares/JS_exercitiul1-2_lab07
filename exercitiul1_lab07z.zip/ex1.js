function schimb()
{
    document.getElementById("Job").innerHTML = "Embedded System Ingineer"
	document.getElementById("Job").style.fontFamily = "Impact,Charcoal,sans-serif"
    document.getElementById("0").innerHTML = ""
    document.getElementById("Goal1").innerHTML = "Experiente Ideale"
    document.getElementById("Goal2").innerHTML = "Intership la Pentalog"
    document.getElementById("Goal3").innerHTML = "Proiecte de cercetare sau contribuții academice"
    document.getElementById("Goal4").innerHTML = "Participarea în organizații studențești sau voluntariat"
    document.getElementById("Goal5").innerHTML = "Studii internaționale sau schimburi academice"


	oldToNewImage() ;
	document.body.style.backgroundColor = "Orange";
}

function oldToNewImage() {
	let img = document.getElementById("PozaNoua");
	img.src = "altapoza.jpg";
	img.style.opacity = 1;
	img.style.filter = "blur(0)";
}

function calculVarsta() {
    var anulNasterii = document.getElementById("birthYear").value;
    var lunaNasterii = document.getElementById("birthMonth").value;
    var ziuaNasterii = document.getElementById("birthDay").value;

    var dataNasterii = new Date(anulNasterii, lunaNasterii - 1, ziuaNasterii); 
    var acum = new Date();
    var varsta = acum.getFullYear() - dataNasterii.getFullYear();
    if (
        acum.getMonth() < dataNasterii.getMonth() ||
        (acum.getMonth() === dataNasterii.getMonth() && acum.getDate() < dataNasterii.getDate())
    ) {
        varsta--;
    }
    document.getElementById("varsta").innerText = "Vârsta: " + varsta + " ani";
}

function validareEmail() {
    var email = document.getElementById("email").value;
    if (email.includes('@')) {
        alert('Adresa de e-mail este validă!');
    } else {
        alert('Introduceți o adresă de e-mail validă!');
    }
}

function ascundeData() {
    document.getElementById("varsta").innerText = "Puneți mouse-ul aici pentru a afișa vârsta.";
        }


